#include "Graph.h"
#include <vector>
#include <map>  
#include <list>
#include <queue>
#include <iostream>
#include <string>
#include <algorithm>
#include <exception>
#include <stdio.h>
#include <math.h> 
#define INF 0x3f3f3f3f
typedef std::pair<int, int> iPair;

// Resizes and sets the size for vectors
void Graph::setNumNodes(int num) {
    adj_list.resize(num);
    vertices.resize(num);
    edges.resize(num);
    num_nodes = num;
    adj = new std::list<iPair>[num];
}

// Adds edges to adjacency list
void Graph::addEdge(int a, int b) {
    adj_list[map_nodes.at(a)].push_back(map_nodes.at(b));
    int distance = sqrt(pow(a, 2) + pow(b,2));
    adj[map_nodes.at(a)].push_back(std::make_pair(map_nodes.at(b), distance));
}

// Adds vertices to map nodes to map the nodes to a specific id
void Graph::addVertex(int n) {
    if (map_nodes.find(n) == map_nodes.end()) {
        map_nodes.insert(std::pair<int, int>(n, counter));
        map_ids.insert(std::pair<int, int>(counter, n));
        vertices[counter] = "UNEXPLORED";
        counter+=1;
    }
}

std::vector<std::vector<int>> Graph::getNodes() {
    return adj_list;
}
  
int Graph::getNumNodes() {
    return num_nodes;
}

// Helper function for IDDFS
bool Graph::DLS(int src, int target, int limit) {
    if (src == target) {
        return true;
    }
    if (limit <= 0) {
        return false;
    }

    for (auto i = adj_list[src].begin(); i != adj_list[src].end(); ++i) {
       if (DLS(*i, target, limit-1) == true) {
          return true;
       }
        
    }
     return false;
}

// Takes in the id of the source node and target, returns if there is a path that exists between them
std::string Graph::IDDFS(int src, int target) {
    int source = 0;
    int targ = 0;
    if (convertId(src) == -1) {
        return "Invalid starting intersection.";
    }
    source = convertId(src);
    if (convertId(target) == -1) {
        return "Invalid target intersection.";
    }
    targ = convertId(target);
    for (int i = 0; i <= 10; i++) {
       if (DLS(source, targ, i) == true) {
           return "The target intersection was found.";
       }
    }
    return "The target intersection was not found.";
}

// Converts id to a specific index in a map
int Graph::convertId(int id) {
    if (map_nodes.find(id) == map_nodes.end()) {
        return -1;
    }
    int index = map_nodes.at(id);
    return index;
}

// BFS traversal to mark each edge as visited, and as cross or discovery
void Graph::BFS() {
    for (unsigned i = 0; i < edges.size(); i++) {
        edges[i].resize(adj_list[i].size());
        for (unsigned j = 0; j < edges[i].size(); j++) {
            edges[i][j] = "UNEXPLORED";
        }
    }
    for (unsigned i = 0; i < vertices.size(); i++){
        if (vertices[i] == "UNEXPLORED") {
            BFS(i);
        }
    }
}

// Helper function for BFS that takes in a node
void Graph::BFS(int i) {
    std::queue<int> q;
    vertices[i] = "VISITED";
    q.push(i);
    while (!q.empty()) {
        int i = q.front();
        q.pop();
        for (unsigned j = 0; j < adj_list[i].size(); j++) {
            if (vertices[adj_list[i][j]] == "UNEXPLORED") {
                edges[i][j] = "DISCOVERY";
                vertices[adj_list[i][j]] = "VISITED";
                q.push(adj_list[i][j]);
            } else if (edges[i][j] == "UNEXPLORED") {
                edges[i][j] = "CROSS";
            }
        }
    }

    for (unsigned i = 0; i < edges.size(); i++) {
        for (unsigned j = 0; j < edges[i].size() ; j++) {
            std::cout << edges[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

std::vector<std::vector<std::string>> Graph::getEdges() {
    return edges;
}

// Djikstra's Algorithm to find the distance of the shortest path from a source to other nodes in the dataset. 
// The second argument is to find the shortest distance from a specific node to a specific target 
void Graph::shortestPath(int src, int target)
{
    int source = 0;
    int targ = 0;
    if (convertId(src) == -1) {
        throw std::exception();
    }
    source = convertId(src);
    if (convertId(target) == -1) {
        throw std::exception();
    }
    targ = convertId(target);

    // Create a priority queue to store vertices
    std::priority_queue< iPair, std::vector <iPair> , std::greater<iPair> > pq;
  
    // Create a vector for distances and initialize all distances as infinite 
    std::vector<int> dist(num_nodes, INF);
  
    // Insert source itself in priority queue and initialize its distance as 0.
    pq.push(std::make_pair(0, source));
    dist[source] = 0;
  
    /* Looping till priority queue becomes empty (or all
      distances are not finalized) */
    while (!pq.empty())
    {
        // The first vertex in pair is the minimum distance
        // vertex, extract it from priority queue.
        // vertex label is stored in second of pair (it
        // has to be done this way to keep the vertices
        // sorted distance (distance must be first item
        // in pair)
        int u = pq.top().second;
        pq.pop();
  
        // 'i' is used to get all adjacent vertices of a vertex
        for (std::list< std::pair<int, int> >::iterator i = adj[u].begin(); i != adj[u].end(); ++i)
        {
            // Get vertex label and weight of current adjacent of u.
            int v = (*i).first;
            int weight = (*i).second;
  
            //  If there is shorter path to v through u, it will update the distance
            if (dist[v] > dist[u] + weight)
            {
                dist[v] = dist[u] + weight;
                pq.push(std::make_pair(dist[v], v));
            }
        }
    }
    test_dists.push_back(map_ids.at(source));
    test_dists.push_back(map_ids.at(targ));
    test_dists.push_back(dist[targ]);
}

std::vector<int> Graph::getTestDists() {
    return test_dists;
}