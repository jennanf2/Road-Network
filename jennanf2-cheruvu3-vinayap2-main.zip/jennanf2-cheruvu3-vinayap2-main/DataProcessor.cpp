#include "DataProcessor.h"
#include "Graph.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include "istream"

// Takes in a txt file
std::istream& operator>>(std::istream& is, DataProcessor& dataprocessor) {
    int num_nodes;
    int line_count = 0;
    std::string line;
    // Seperates each line
    while (std::getline(is, line)) {
        if (line.empty()) {
            continue;
        }
        // Gets total number of nodes from txt file
        if (line.find("# Nodes:") != std::string::npos) {  //Checks if number of nodes is a substring of the first line
            line.erase(std::remove_if(line.begin(), line.end(), isspace), line.end());
            std::string num_nodes_string = line.substr(7, line.find((char) 69)); //Finds number of nodes
            try {
                num_nodes = std::stoi(num_nodes_string);
            } catch(std::invalid_argument& e) {
                std::cout << "Cannot convert " << num_nodes_string << " to integer" << std::endl;
            }
            dataprocessor.graph.setNumNodes(num_nodes);
        }
        // Gets vertices and edges from line
        if (line_count >= 4) {

            int node1;
            int node2;
            std::string first_node;
            std::string second_node;
            bool first = true;

            for(char i : line) {
                // If the character is a number (0-9) adds it to the node
                if (int(i) >= 48 && int(i) <= 57) {
                    if (first) {
                        first_node += i;
                    } else {
                        second_node += i;     
                    }
                } else {
                    first = false;
                } 
            }
            
            try {
                node1 = std::stoi(first_node);
            } catch(std::invalid_argument& e) {
                std::cout << "Cannot convert " << node1 <<" to integer" << std::endl;
            }
            try {
                node2 = std::stoi(second_node);
            } catch(std::invalid_argument& e) {
                std::cout << "Cannot convert " << node2 <<" to integer" << std::endl;

            }
            dataprocessor.graph.addVertex(node1);
            dataprocessor.graph.addVertex(node2);
            dataprocessor.graph.addEdge(node1, node2);
        }
        line_count++;
   }
   return is;
}


Graph DataProcessor::getGraph() {
    return graph;
}