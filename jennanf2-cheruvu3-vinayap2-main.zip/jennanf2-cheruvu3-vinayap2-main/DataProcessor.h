#pragma once
#include <vector>
#include "istream"
#include "Graph.h"
#include <string>

class DataProcessor {
 public:
    DataProcessor() = default;
    friend std::istream& operator>>(std::istream& is, DataProcessor& dataprocessor);
    Graph getGraph();

  private:
    Graph graph;

 
};
