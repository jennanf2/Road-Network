#pragma once
#include <vector>
#include <map>  
#include <list>
#include <string>

class Graph {
    public:
        Graph() = default;
        void setNumNodes(int num);
        void addVertex(int n);
        void addEdge(int a, int b);
        std::string IDDFS(int source, int target);
        bool DLS(int source, int target, int limit);
        int convertId(int id);
        void BFS();
        void BFS(int i);
        void shortestPath(int src, int target);
        // Getters
        int getNumNodes();
        std::vector<std::vector<int>> getNodes();
        std::vector<std::vector<std::string>> getEdges();
        std::vector<int> getTestDists();
        
    private:
        int num_nodes = 0;        
        int counter = 0;
        std::vector<std::vector<int>> adj_list;
        std::vector<std::vector<std::string>> edges;
        std::vector<std::string> vertices;
        std::map<int, int> map_nodes;
        std::map<int, int> map_ids;
        std::vector<int> test_ids;
        std::vector<int> test_dists;
        std::list< std::pair<int, int> > *adj;
};