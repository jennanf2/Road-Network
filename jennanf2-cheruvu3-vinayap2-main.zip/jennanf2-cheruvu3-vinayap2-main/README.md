# CS 225 Fall 2021 Final Project jennanf2-cheruvu3-vinayap2

Group Members:
Jenna Fong
Chetana Cheruvu
Vinaya Pillai

## California Road Network:
Our project uses the dataset obtained from http://snap.stanford.edu/data/roadNet-CA.html which is a directed graph that displays edges as integers formed by two vertices that represents road network itersections. Our goal is to see if a path exists from one road to another, and if so, find the shortest path between them.   

To run main, which displays the results of our data processing, algorithms, and traversal on a subset of the data, first type **module load llvm/6.0.1** into the terminal, then **make**, and finally **./roads**. Changing the filename variable will change the txt file you will run the code on.

To run our tests, first type **module load llvm/6.0.1** into the terminal, then **make test**, and finally **./test**. To see specifically what is being tested in our project, refer to "Tests" below. 

Here is our final presentation video: https://drive.google.com/file/d/1b2gLrnVobTXDxu4NHlW9Bb9DE_GgmHZU/view?usp=sharing

- - - -
## DataProcessor:
### Files: DataProcessor.h/cpp
The data processor system takes in a txt file and extracts each line to process. From the files it reads in the number of nodes as well as each vertex and edge into their respective variables in the graph.

- - - -
## Graph:
### Files: Graph.h/cpp
The graph object takes in vertex and edges from the dataset and performs several algorithms and a BFS traversal. It creates weights for each edge using the distance formula. It also creates an adjacency list from all of the nodes and performs an Iterative Deepening Depth-First search to see if a path exists from one node to another. It also uses a BFS traversal to mark each edge as CROSS and DISCOVERY. Finally, we use Dijkstra's algorithm to find the distance of the shortest path from the source node that is passed in to other nodes in the dataset. A second argument is used to see the shortest distance to a specific target node.

- - - -
## Tests:
### Files: tests/
All testing of the code is done within the tests folder. DataProccessorTest.cpp tests the processing of the txt files while GraphTest.cpp tests the algorithms and traversal. Each test is named what they are testing for.

To reproduce tests, create a test case in one of the test files. You will need to create a txt file and a DataProcessor object to read it in. Then, use the getter in the DataProcessor to get the graph produced. After, you can write REQUIRE to test for a specific requirement.


