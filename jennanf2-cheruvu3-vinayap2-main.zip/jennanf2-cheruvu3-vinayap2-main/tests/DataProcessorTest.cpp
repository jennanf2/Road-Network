#include "../cs225/catch/catch.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stack>
#include "../DataProcessor.h"
#include "../Graph.h"

using namespace std;

TEST_CASE("Correctly processes number of nodes in graph - small dataset")
{
	std::string filename = "Data/testroads.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } else {
        std::cerr << "File could not be opened" << std::endl;
    }
    REQUIRE(data.getGraph().getNumNodes() == 5);
}

TEST_CASE("Adds correct number of vertices - small dataset")
{
	std::string filename = "Data/testroads.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    REQUIRE(data.getGraph().getNodes().size() == 5);
}

TEST_CASE("Adds correct number of edges - small dataset")
{
	std::string filename = "Data/testroads.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    std::vector<std::vector<int>> graph = data.getGraph().getNodes();
    int count = 0;
    for (std::vector<int> i : graph) {
        for (int j : i) {
            count++;
        }
    }
    REQUIRE(count == 6);
}

TEST_CASE("Correctly processes number of nodes in graph - medium dataset")
{
    std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } else {
        std::cerr << "File could not be opened" << std::endl;
    }
    REQUIRE(data.getGraph().getNumNodes() == 8);
}

TEST_CASE("Adds correct number of vertices - medium dataset")
{
    std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    REQUIRE(data.getGraph().getNodes().size() == 8);
}

TEST_CASE("Adds correct number of edges - medium dataset")
{
    std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    std::vector<std::vector<int>> graph = data.getGraph().getNodes();
    int count = 0;
    for (std::vector<int> i : graph) {
        for (int j : i) {
            count++;
        }
    }
    REQUIRE(count == 22);
}