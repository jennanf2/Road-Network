#include "../cs225/catch/catch.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <stack>
#include "../DataProcessor.h"
#include "../Graph.h"

using namespace std;

TEST_CASE("Correctly indicates if a path exists from one road to another")
{
	std::string filename = "Data/testroads.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    REQUIRE(data.getGraph().IDDFS(0, 1) == "The target intersection was found.");
}

TEST_CASE("Correctly indicates no path exists from one road to another")
{
	std::string filename = "Data/testroads.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    REQUIRE(data.getGraph().IDDFS(0, 3) == "The target intersection was not found.");
}

TEST_CASE("Correctly identifies edge as discovery edge") {
	std::string filename = "Data/testroads2.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.BFS();
    REQUIRE(g.getEdges().at(0).at(0) == "DISCOVERY");
}

TEST_CASE("Correctly identifies edge as cross edge") {
	std::string filename = "Data/testroads2.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.BFS();
    REQUIRE(g.getEdges().at(1).at(1) == "CROSS");
}

TEST_CASE("Correctly finds shortest path using Djikstra Algorithm (multiple paths)") {
	std::string filename = "Data/testroads2.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.shortestPath(0, 2);
    REQUIRE(g.getTestDists().at(0) == 0);
    REQUIRE(g.getTestDists().at(1) == 2);
    REQUIRE(g.getTestDists().at(2) == 2);
}

TEST_CASE("Correctly finds shortest path using Djikstra Algorithm (no direct path)") {
	std::string filename = "Data/testroads2.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.shortestPath(0, 5);
    REQUIRE(g.getTestDists().at(0) == 0);
    REQUIRE(g.getTestDists().at(1) == 5);
    REQUIRE(g.getTestDists().at(2) == 7);
}

TEST_CASE("Correctly finds shortest pathn using Djikstra Algorithm(direct paths) - medium dataset") {
	std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.shortestPath(9, 0);
    REQUIRE(g.getTestDists().at(0) == 9);
    REQUIRE(g.getTestDists().at(1) == 0);
    REQUIRE(g.getTestDists().at(2) == 9);
}

TEST_CASE("Correctly finds shortest path using Djikstra Algorithm(two paths of same size) - medium dataset") {
	std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.shortestPath(5, 7);
    REQUIRE(g.getTestDists().at(0) == 5);
    REQUIRE(g.getTestDists().at(1) == 7);
    REQUIRE(g.getTestDists().at(2) == 12);
}

TEST_CASE("Correctly indicates if a path exists from one road to another - medium dataset")
{
    std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    REQUIRE(data.getGraph().IDDFS(0, 1) == "The target intersection was found.");
}

TEST_CASE("Correctly indicates no path exists from one road to another - medium dataset")
{
    std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    REQUIRE(data.getGraph().IDDFS(0, 3) == "Invalid target intersection.");
}

TEST_CASE("Correctly identifies edge as discovery edge  - medium dataset") {
    std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.BFS();
    REQUIRE(g.getEdges().at(0).at(1) == "DISCOVERY");
}

TEST_CASE("Correctly identifies edge as cross edge  - medium dataset") {
    std::string filename = "Data/testroads3.txt";
    DataProcessor data;
    std::ifstream input_file(filename);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } 
    Graph g = data.getGraph();
    g.BFS();
    REQUIRE(g.getEdges().at(2).at(1) == "CROSS");
}