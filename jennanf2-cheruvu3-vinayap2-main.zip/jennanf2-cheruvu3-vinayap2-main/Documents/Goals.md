## Leading Question
Is there a path between two intersections? If there is, what is the shortest path between the two intersections?  
 
## Dataset Acquisition and Processing
Our project will use the California Road Network dataset: http://snap.stanford.edu/data/roadNet-CA.html
We will download the file and unzip it to access the dataset. We will copy the txt file into our repository. The file stores a directed graph that contains node IDs, listing the edges from one node ID to another ID. There will be a class representing each road intersection as a node, so we will convert each line of data from the txt to a C++ node. Since the dataset lists the connections between roads, we will store the roads that each node connects to. This can be accomplished using an adjacency matrix. The elements in the matrix indicate whether pairs of vertices are adjacent or not in the directed graph. Some potential errors we may come across is missing roads or unconnected roads. This would entail multiple connected components. So to find the shortest path between two roads, the two inputted roads must be in the same connected component. We also have to make sure that the inputted nodes are not the same intersection twice and that there is at least two intersections in each connected component. 
 
Graph Algorithms - We will use the Dijkstra’s Algorithm with a priority queue to find the shortest path between two intersections.

For our complex algorithm, we will use an iterative deepening depth first search to see if an intersection is reachable from another intersection. In other words, we are trying to figure out if there is a road that connects two intersections. If not, this algorithm will return a boolean indicating the intersection is not reachable from the starting node. This complex algorithm combines depth-first search and breadth-first search to make a better search function for a larger dataset. If ‘d‘ is depth, and ‘b‘ is the branching factor, then DFS/BFS/IDDFS takes O(b^d) time complexity and O(d), O(b^d), and O(bd) space complexity respectively. The input for this algorithm is the starting intersection and the ending intersection. The output would say whether the ending intersection is reachable.

Once we know if the intersection is reachable, we will use Dijkstra’s Algorithm to figure out the shortest path between the intersections. Dijkstra’s algorithm uses a breadth-first search. Since we would like to find the shortest travel distance between two intersections, the appropriate weight for the edges is the road mileage between the two nodes. Dijstra’s algorithm has a time complexity of O(V^2) which can be reduced to O(ElogV) with an adjacency matrix. For the implementation of Dijkstra’s Algorithm, first we will mark all the nodes as unvisited. Then we will create an adjacency matrix of the shortest paths from the starting source node and all other nodes. This entails calculating the path lengths of neighboring nodes and replacing the minimum length if we find a shorter one. The current node will be marked as visited and the node with the shortest path length will become the new current node. The input for this algorithm is the weighted graph of the roads and the source node. The output of the data is the shortest path from one intersection to another and it will display the node numbers needed to get to the target on this path. 
## Graph Algorithms 
We will use the Dijkstra’s Algorithm with a priority queue to find the shortest path between two intersections. Dijkstra’s algorithm uses a breadth-first search. For our complex algorithm, we will use an iterative deepening depth first search to see if an intersection is reachable from another intersection. In other words, we are trying to figure out if there is a road that connects two intersections. If not, this algorithm will return a boolean indicating the intersection is not reachable from the starting node. This complex algorithm combines depth-first search and breadth-first search to make a better search function for a larger dataset. If ‘d‘ is depth, and ‘b‘ is the branching factor, then DFS/BFS/IDDFS takes O(b^d) time complexity and O(d), O(b^d), and O(bd) space complexity respectively. Once we know if the intersection is reachable, we will use Dijkstra’s Algorithm to figure out the shortest path between the intersections. Dijstra’s algorithm has a time complexity of O(V^2) which can be reduced to O(ElogV) with an adjacency matrix. For the implementation of Dijkstra’s Algorithm, first we will mark all the nodes as unvisited. Then we will create an adjacency matrix of the shortest paths from the starting source node and all other nodes. This entails calculating the path lengths of neighboring nodes and replacing the minimum length if we find a shorter one. The current node will be marked as visited and the node with the shortest path length will become the new current node.
 
http://theoryofprogramming.com/2018/01/14/iterative-deepening-depth-first-search-iddfs/
 
Timeline 
 
Tasks Include:
Download and store dataset in repository
   2. Create adjacency matrix out of the nodes given in our dataset
   3. Complete the shortest path algorithm
   4. Complete the iterative deepening depth first search algorithm
   5. Create final presentation video 
 
Timeline:
	Week 1: Finish tasks 1 and 2
	Week 2: Finish task 3
	Week 3: Finish task 4
	Week 4: Finish task 5
