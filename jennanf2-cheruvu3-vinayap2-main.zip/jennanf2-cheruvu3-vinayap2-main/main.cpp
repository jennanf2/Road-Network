#include <iostream>
#include <fstream>
#include "DataProcessor.h"


int main() {
    std::string filename0 = "Data/roadNet-CA.txt";
    DataProcessor data0;
    std::ifstream input_file0(filename0);
    if (input_file0.is_open()) {
        input_file0 >> data0;
        input_file0.close();
    } else {
        std::cerr << "File could not be opened" << std::endl;
    }
    // Number of intersections
    std::cout << "Number of nodes: " << data0.getGraph().getNumNodes() << std::endl;
    // Path exists
    std::cout <<  "IDDFS from 13 to 77: " << data0.getGraph().IDDFS(13, 77) << std::endl;
    // Path exists
    std::cout <<  "IDDFS from 0 to 3: " << data0.getGraph().IDDFS(0, 3) << std::endl;
    // Specific intersection is invalid
    std::cout <<  "IDDFS from 0 to 553243: " << data0.getGraph().IDDFS(0, 553243) << std::endl;

    // Djikstra's
    std::cout << "Djikstra's Output:" << std::endl;
    if (data0.getGraph().IDDFS(13, 77) == "The target intersection was found.") {
        Graph g1 = data0.getGraph();
        g1.shortestPath(13, 77);
        std::cout << "Shortest distance from 13 to 77: " << g1.getTestDists().at(2) << " miles. "<< std::endl;

    }

    std::cout << std::endl;
    
    std::string filename1 = "Data/testroads.txt";
    DataProcessor data;
    std::ifstream input_file(filename1);
    if (input_file.is_open()) {
        input_file >> data;
        input_file.close();
    } else {
        std::cerr << "File could not be opened" << std::endl;
    }
    // Number of intersections
    std::cout << "Number of nodes: " << data.getGraph().getNumNodes() << std::endl;
    // Path exists
    std::cout <<  "IDDFS from 0 to 1: " << data.getGraph().IDDFS(0, 1) << std::endl;
    // Path does not exist
    std::cout <<  "IDDFS from 0 to 3: " << data.getGraph().IDDFS(0, 3) << std::endl;
    // Specific intersection is invalid
    std::cout <<  "IDDFS from 0 to 553243: " << data.getGraph().IDDFS(0, 553243) << std::endl;

    std::cout << std::endl;

    std::string filename2 = "Data/testroads2.txt";
    DataProcessor data2;
    std::ifstream input_file2(filename2);
    if (input_file2.is_open()) {
        input_file2 >> data2;
        input_file2.close();
    } else {
        std::cerr << "File could not be opened" << std::endl;
    }
    // BFS
    std::cout << "BFS Output:" << std::endl;
    data2.getGraph().BFS();

    std::cout << std::endl;

    // Djikstra's
    std::cout << "Djikstra's Output:" << std::endl;
    if (data2.getGraph().IDDFS(0, 2) == "The target intersection was found.") {
        Graph g = data2.getGraph();
        g.shortestPath(0, 2);
        std::cout << "Shortest distance from 0 to 2: " << g.getTestDists().at(2) << " miles. "<< std::endl;

    }

    std::string filename3 = "Data/testroads3.txt";
    DataProcessor data3;
    std::ifstream input_file3(filename3);
    if (input_file3.is_open()) {
        input_file3 >> data3;
        input_file3.close();
    } else {
        std::cerr << "File could not be opened" << std::endl;
    }
    // Number of intersections
    std::cout << "Number of nodes: " << data3.getGraph().getNumNodes() << std::endl;
    // Path exists
    std::cout <<  "IDDFS from 0 to 1: " << data3.getGraph().IDDFS(5, 7) << std::endl;
    // Path does not exist
    std::cout <<  "IDDFS from 0 to 3: " << data3.getGraph().IDDFS(0, 3) << std::endl;
    // Specific intersection is invalid
    std::cout <<  "IDDFS from 0 to 553243: " << data3.getGraph().IDDFS(0, 553243) << std::endl;

    // Djikstra's
    std::cout << "Djikstra's Output:" << std::endl;
    if (data3.getGraph().IDDFS(5, 7) == "The target intersection was found.") {
        Graph g2 = data3.getGraph();
        g2.shortestPath(5, 7);
        std::cout << "Shortest distance from 5 to 7: " << g2.getTestDists().at(2) << " miles. "<< std::endl;

    }

    std::cout << std::endl;

}